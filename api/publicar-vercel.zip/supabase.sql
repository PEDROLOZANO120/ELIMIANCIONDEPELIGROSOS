-- Obra Maldita - tablas para Supabase.
-- Pégalo completo en Supabase > SQL Editor > New query > Run.

create table if not exists public.config (
  id            int primary key check (id = 1),   -- una sola fila
  abierto       boolean not null default false,
  iniciado_en   double precision,
  ganador       text
);
insert into public.config (id) values (1) on conflict (id) do nothing;

create table if not exists public.grupos (
  id             text primary key,
  nombre         text not null,
  fichas         int not null default 0,
  completado_en  double precision,
  datos          jsonb not null,                  -- respuestas, salidas, PIN, etc.
  actualizado    timestamptz not null default now()
);

-- Seguridad: activar RLS SIN políticas = ni la clave pública (anon) ni usuarios
-- autenticados pueden leer o escribir. Solo la clave service_role del servidor.
alter table public.config enable row level security;
alter table public.grupos enable row level security;
revoke all on public.config from anon, authenticated;
revoke all on public.grupos from anon, authenticated;
