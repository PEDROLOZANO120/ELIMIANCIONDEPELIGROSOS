# Publicar Obra Maldita en Vercel + Supabase

Tiempo estimado: 20 a 30 minutos la primera vez. Necesitas cuentas en **GitHub**, **Supabase** y **Vercel** (las tres tienen plan gratuito).

## Qué cambia respecto a la versión local

| | Local (`INICIAR.bat`) | Internet (esta carpeta) |
|---|---|---|
| Servidor | Tu computador encendido | Vercel (funciones) |
| Datos | `datos/estado.json` | Supabase (Postgres) |
| Sesión del grupo | En memoria | Token firmado (dura 12 h) |
| Acceso | Misma red Wi-Fi | Cualquier dispositivo con internet |
| Consulta de pantalla | cada 5 s | cada 8 s (docente cada 5 s) |

Las reglas del juego, las preguntas, los informes PDF y el panel docente son los mismos.

## Carpeta que se sube

Se sube **el contenido de esta carpeta `publicar-vercel`** (no la carpeta superior):

```
api/index.py        servidor del juego
api/preguntas.json  banco con las respuestas (NO es público: queda dentro del servidor)
public/             pantalla de grupos y panel docente
vercel.json         enrutado
supabase.sql        tablas de la base de datos
.env.example        lista de variables (sin valores reales)
```

## Paso 1 · Supabase (la base de datos)

1. En supabase.com → **New project**. Ponle un nombre (por ejemplo `obra-maldita`), crea una contraseña de base de datos (guárdala) y elige la región **East US (North Virginia)**, que queda cerca de Vercel y reduce la demora.
2. Cuando termine de crearse, abre **SQL Editor → New query**, pega **todo** el contenido de `supabase.sql` y pulsa **Run**. Debe decir que se ejecutó sin errores.
3. Ve a **Project Settings → API** y copia:
   - **Project URL** → será `SUPABASE_URL`.
   - La clave **service_role** (la secreta; en la pantalla puede aparecer como «secret» o con un botón «Reveal») → será `SUPABASE_SERVICE_KEY`.
4. **Nunca** pongas la clave `service_role` en el navegador, en un mensaje ni en GitHub. Da control total de la base.

## Paso 2 · GitHub

1. Crea un repositorio nuevo, **privado**, por ejemplo `obra-maldita`.
2. Sube el contenido de esta carpeta (en GitHub: **Add file → Upload files**, arrastra las carpetas `api` y `public` y los archivos sueltos).
3. Comprueba que **no** subiste ningún archivo `.env` con claves. El `.gitignore` incluido ya lo evita si usas git.

## Paso 3 · Vercel

1. En vercel.com → **Add New… → Project** y elige el repositorio.
2. **Framework Preset: Other.** Deja **Root Directory** vacío (la raíz) y no pongas comandos de build.
3. Abre **Environment Variables** y agrega estas 4 (los nombres exactos):

| Nombre | Valor |
|---|---|
| `SUPABASE_URL` | La URL del paso 1 |
| `SUPABASE_SERVICE_KEY` | La clave `service_role` del paso 1 (también se acepta el nombre `SUPABASE_SERVICE_ROLE_KEY`, que usa la integración Supabase–Vercel) |
| `DOCENTE_CLAVE` | Una clave larga que solo tú sabrás (la usarás en `/docente`) |
| `SESSION_SECRET` | Una cadena aleatoria larga (ver abajo) |

Para generar `SESSION_SECRET`, abre PowerShell y pega esto:

```powershell
$b = New-Object byte[] 32; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); [Convert]::ToBase64String($b)
```

4. Pulsa **Deploy**. Al terminar, Vercel te da una dirección como `https://obra-maldita.vercel.app`.

## Paso 4 · Probar antes de la clase

1. Abre `https://TU-DIRECCION/docente`, escribe tu `DOCENTE_CLAVE` y crea 2 grupos de prueba (`Prueba A;1111;Ana Pérez, Luis Mora` y `Prueba B;2222;Rosa Cruz, Pedro Vera`). Los grupos entran resolviendo el **acertijo de letras revueltas** con los nombres de sus integrantes (o con el PIN como respaldo).
   - **Grupos reales:** abre el archivo `grupos_semana4.txt` de la carpeta superior, copia su contenido y pégalo en «Crear grupos» del panel. A propósito, **los nombres de los estudiantes no están dentro de este paquete** para que no queden en GitHub.
2. Abre la dirección principal en dos celulares, entra con los grupos y pulsa **Abrir reto** en el panel.
3. Responde unas preguntas y comprueba: fichas, tablero, salidas (cambia de pestaña), panel y descarga del PDF.
4. Al terminar el ensayo, en el panel pulsa **Borrar todo y empezar de cero**, y crea los grupos reales.

## Si algo falla

| Síntoma | Causa probable |
|---|---|
| «Servidor sin configurar (faltan variables…)» | Falta alguna de las 4 variables en Vercel. Agrégala y haz **Redeploy**. |
| «Error temporal de base de datos» | `SUPABASE_URL` o la clave están mal, o no corriste `supabase.sql`. |
| Las pantallas cargan pero todo da 404 en `/api/...` | `vercel.json` no quedó en la raíz del repositorio: subiste la carpeta superior en lugar de su contenido. |
| La clave del docente «incorrecta» | Revisa `DOCENTE_CLAVE`; tras cambiar variables hay que **Redeploy**. |
| Otro error | En Vercel: **Deployments → tu despliegue → Functions / Logs**. Cópiame el mensaje y lo corrijo. |

## Datos personales y seguridad

- La base guarda nombres de grupo, integrantes que escribas, PIN, respuestas y salidas. Borra los datos cuando ya no los necesites (**Borrar todo** en el panel, o la tabla `grupos` en Supabase).
- Tras 5 PIN incorrectos seguidos, ese grupo queda bloqueado 60 segundos (frena adivinar PIN). Aun así, un PIN de 4 dígitos protege contra errores, no contra un ataque decidido. Para algo más estricto, usa PIN largos o el acceso individual por cédula (puedo agregarlo si me das el listado).
- El archivo `api/preguntas.json` y la clave `service_role` solo existen en el servidor. La parte pública (`public/`) no contiene respuestas.
- Las tablas están protegidas (RLS activado sin políticas): la clave pública de Supabase no puede leerlas ni escribirlas.
- Revisa que el plan gratuito de Vercel cubra tu uso (el plan Hobby está pensado para uso personal sin fines comerciales).

## Qué se probó y qué no

**Probado en mi equipo:** toda la lógica contra un **Supabase simulado** (un mini servidor que imita su API): los 5 tipos de ítem y el crédito parcial, fichas, nota 85 % zonas + 15 % reto final (crucigrama y sopa), mínimo del 50 % del reto para ganar, extras solo después del reto, salidas, PDF, token firmado (se rechaza si lo alteran), orden de preguntas, claves del docente, acertijo de ingreso, y que el ganador sea siempre el **primero** aunque otro grupo termine después.

**Qué incluye esta versión (igual que la local):** 4 zonas de 8 ítems (relacionar, completar, ordenar, selección única y múltiple), turnos rotativos para los 4 integrantes, reto final con crucigrama y sopa de letras repartidos por integrante, ingreso con acertijo de letras revueltas, panel docente con «preguntas más falladas» e informes PDF. La **duración recomendada es de unos 110 minutos** (≈ 90 las zonas + ≈ 20 el reto final); si tu clase es de 90, usa **Pausar reto** en el panel y entrega el reto final en otra sesión: el estado se conserva en Supabase.

**No probado:** el despliegue real en Vercel ni la conexión con un Supabase real. Los puntos más probables de ajuste, si algo no responde, son: el enrutado en `vercel.json`, la carpeta de salida `public`, y la inclusión de `api/preguntas.json` en la función. Tampoco se probó con muchos dispositivos a la vez. Haz el ensayo del Paso 4 con anticipación y, si hay un error, pásame el mensaje del registro.
