"""
Obra Maldita - API para Vercel (Python) + Supabase (Postgres).
Todo el estado vive en Supabase; ninguna variable depende de que el proceso siga encendido.
Variables de entorno obligatorias: SUPABASE_URL, SUPABASE_SERVICE_KEY, DOCENTE_CLAVE, SESSION_SECRET.
La clave service_role SOLO se usa aquí (servidor). Nunca llega al navegador.
"""
import json, os, hmac, hashlib, random, secrets, sys, time, textwrap, threading, traceback, unicodedata
import urllib.request, urllib.parse, urllib.error
from http.server import BaseHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------- reglas del juego (iguales a la versión local) ----------
PIEZAS_POR_TEMA = 4
UMBRALES = [(0.85, 4), (0.65, 3), (0.45, 2), (0.25, 1)]   # (fracción mínima de la zona, fichas)
SALIDAS_GRATIS = 2
DESCUENTO_SALIDA = 0.5
NOTA_MAX = 10.0
DURACION_SESION = 12 * 3600

with open(os.path.join(HERE, "preguntas.json"), encoding="utf-8") as f:
    BANCO = json.load(f)
TEMAS = BANCO["temas"]
NUM_TEMAS = len(TEMAS)
TOTAL_PIEZAS = NUM_TEMAS * PIEZAS_POR_TEMA
PREG = {}
for _t in TEMAS:
    for _q in _t["preguntas"]:
        PREG[_q["id"]] = (_q, _t["id"], False)
    for _q in _t.get("extras", []):
        PREG[_q["id"]] = (_q, _t["id"], True)
TOTAL_PRINCIPAL = sum(len(t["preguntas"]) for t in TEMAS)
RETO = BANCO["reto_final"]                 # crucigrama + sopa de letras
PESO_RETO = float(RETO.get("peso", 0.15))  # parte de la nota que vale el reto final
MIN_RETO_GANAR = 0.5   # para ganar el punto directo hace falta al menos este porcentaje del reto final


def env(n):
    v = os.environ.get(n, "")
    if not v and n == "SUPABASE_SERVICE_KEY":      # nombre que usa la integración Supabase–Vercel
        v = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    return v


# ---------- sesiones sin estado: token firmado ----------
def firmar(gid):
    cuerpo = f"{gid}.{int(time.time()) + DURACION_SESION}"
    sig = hmac.new(env("SESSION_SECRET").encode(), cuerpo.encode(), hashlib.sha256).hexdigest()[:40]
    return f"{cuerpo}.{sig}"


def verificar(tok):
    try:
        gid, exp, sig = tok.split(".")
        esperado = hmac.new(env("SESSION_SECRET").encode(), f"{gid}.{exp}".encode(), hashlib.sha256).hexdigest()[:40]
        if env("SESSION_SECRET") and hmac.compare_digest(sig, esperado) and int(exp) > time.time():
            return gid
    except Exception:
        pass
    return None


# ---------- base de datos: Supabase vía PostgREST ----------
class ErrorBD(Exception):
    pass


class Supabase:
    def __init__(self):
        self.base = env("SUPABASE_URL").rstrip("/") + "/rest/v1"
        self.key = env("SUPABASE_SERVICE_KEY")

    def _req(self, metodo, ruta, cuerpo=None, extra=None):
        h = {"apikey": self.key, "Authorization": "Bearer " + self.key, "Content-Type": "application/json"}
        h.update(extra or {})
        data = json.dumps(cuerpo).encode() if cuerpo is not None else None
        r = urllib.request.Request(self.base + ruta, data=data, headers=h, method=metodo)
        try:
            with urllib.request.urlopen(r, timeout=10) as x:
                raw = x.read()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as e:
            print("Supabase HTTP", e.code, e.read()[:300], file=sys.stderr)
            raise ErrorBD()
        except Exception as e:
            print("Supabase error", repr(e), file=sys.stderr)
            raise ErrorBD()

    def config(self):
        r = self._req("GET", "/config?id=eq.1&select=abierto,iniciado_en,ganador")
        return r[0] if r else {"abierto": False, "iniciado_en": None, "ganador": None}

    def set_config(self, campos):
        self._req("PATCH", "/config?id=eq.1", campos, {"Prefer": "return=minimal"})

    def claim_ganador(self, gid):
        """Atómico: solo el primero que llega cambia ganador de NULL a su id."""
        r = self._req("PATCH", "/config?id=eq.1&ganador=is.null", {"ganador": gid}, {"Prefer": "return=representation"})
        return bool(r)

    def grupos(self):
        return {r["id"]: r["datos"] for r in self._req("GET", "/grupos?select=id,datos") or []}

    def grupo(self, gid):
        r = self._req("GET", "/grupos?id=eq." + urllib.parse.quote(str(gid), safe="") + "&select=datos")
        return r[0]["datos"] if r else None

    def guardar_grupo(self, g):
        self._req("POST", "/grupos", {"id": g["id"], "nombre": g["nombre"], "fichas": total_fichas(g),
                                      "completado_en": g["completado_en"], "datos": g},
                  {"Prefer": "resolution=merge-duplicates,return=minimal"})

    def eliminar(self, gid):
        self._req("DELETE", "/grupos?id=eq." + urllib.parse.quote(str(gid), safe=""), None, {"Prefer": "return=minimal"})

    def resumen(self):
        return self._req("GET", "/grupos?select=id,nombre,fichas,completado_en") or []

    def borrar_todo(self):
        self._req("DELETE", "/grupos?id=neq.__ninguno__", None, {"Prefer": "return=minimal"})
        self.set_config({"abierto": False, "iniciado_en": None, "ganador": None})


DB = None
LOCK = threading.Lock()
ESTADO = {"abierto": False, "iniciado_en": None, "ganador": None, "grupos": {}}


def get_db():
    global DB
    if DB is None:
        DB = Supabase()
    return DB


# ---------- lógica del juego (copiada de la versión local) ----------
def nuevo_grupo(nombre, pin, integrantes):
    gid = "g" + secrets.token_hex(3)
    return gid, {
        "id": gid, "nombre": nombre.strip(), "pin": str(pin), "integrantes": integrantes.strip(),
        "resp": {},            # qid -> {sel, ok, p (puntos 0 a 1), t}
        "reto": None,          # resultado del reto final (crucigrama + sopa) cuando lo entregan
        "manual": {},          # tema -> fichas otorgadas por el docente
        "salidas": [],         # [{ini, fin}]
        "salidas_cierre": None,
        "nota": None, "cierre_principal": None,
        "completado_en": None, "ultimo_latido": 0, "creado": time.time(),
    }


def _sin_tildes(s):
    s = unicodedata.normalize("NFD", str(s))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def _norm(s):
    return " ".join(_sin_tildes(s).lower().split())


def integrantes_lista(g):
    """Integrantes separados por coma, punto y coma o salto de línea."""
    return [p.strip() for p in str(g.get("integrantes", "")).replace(";", ",").replace("\n", ",").split(",") if p.strip()]


def revolver(nombre, semilla):
    """Letras desordenadas de cada palabra del nombre, estables para el mismo grupo."""
    palabras = []
    for w in _sin_tildes(nombre).upper().split():
        letras = list(w)
        r = random.Random(f"{semilla}:{w}")
        for _ in range(12):
            r.shuffle(letras)
            if "".join(letras) != w or len(set(w)) == 1:
                break
        palabras.append("".join(letras))
    return " ".join(palabras)


def acertijo_grupo(g):
    return [revolver(n, g["id"]) for n in integrantes_lista(g)]


def respuesta_valida(g, texto):
    """Vale el nombre completo de un integrante (con o sin tildes y mayúsculas); si el nombre tiene
    varias palabras, bastan dos de ellas (por ejemplo nombre y apellido)."""
    t = _norm(texto).split()
    if not t:
        return False
    for n in integrantes_lista(g):
        nt = _norm(n).split()
        if all(x in nt for x in t) and len(set(t)) >= min(2, len(nt)):
            return True
    return False


def intentar_ingreso(g, b):
    """Devuelve 'ok', 'mal' o 'bloqueado'. Acepta el acertijo (respuesta) o el PIN del docente."""
    ahora = time.time()
    if ahora < g.get("bloqueo_hasta", 0):
        return "bloqueado"
    ok = False
    if str(b.get("respuesta", "")).strip():
        ok = respuesta_valida(g, b["respuesta"])
    if not ok and str(b.get("pin", "")).strip():
        ok = secrets.compare_digest(str(b["pin"]).strip(), g["pin"])
    if ok:
        g["fallos"] = 0
        return "ok"
    g["fallos"] = g.get("fallos", 0) + 1
    if g["fallos"] >= 5:   # 5 fallos seguidos: bloqueo de 60 s para ese grupo
        g["bloqueo_hasta"], g["fallos"] = ahora + 60, 0
    return "mal"


def dificiles(grupos, limite=8):
    """Análisis de ítems en vivo: preguntas con más fallos (para repasar en clase)."""
    est = {}
    for g in grupos:
        for qid, r in g["resp"].items():
            if qid in PREG:
                s = est.setdefault(qid, [0, 0])
                s[0] += 1
                s[1] += puntos(r)
    filas = [{"id": qid, "tema": PREG[qid][1], "extra": PREG[qid][2], "texto": PREG[qid][0]["enunciado"][:120],
              "n": n, "aciertos": a, "pct": round(100 * a / n)} for qid, (n, a) in est.items()]
    filas.sort(key=lambda r: (r["pct"], -r["n"], r["id"]))
    return filas[:limite]


def preguntas_principales(g, tema):
    t = next(x for x in TEMAS if x["id"] == tema)
    ids = [q["id"] for q in t["preguntas"]]
    random.Random(f"{g['id']}:orden:{tema}").shuffle(ids)
    return ids


def puntos(r):
    """Puntos de una respuesta guardada: 0 a 1 (relacionar y completar dan crédito parcial)."""
    if "p" in r:
        return float(r["p"])
    return 1.0 if r.get("ok") else 0.0


def aciertos_tema(g, tema):
    t = next(x for x in TEMAS if x["id"] == tema)
    return sum(puntos(g["resp"][q["id"]]) for q in t["preguntas"] if q["id"] in g["resp"])


def respondidas_tema(g, tema):
    t = next(x for x in TEMAS if x["id"] == tema)
    return sum(1 for q in t["preguntas"] if q["id"] in g["resp"])


def fichas_base(aciertos, total):
    for fr, n in UMBRALES:
        if aciertos >= fr * total - 1e-9:
            return n
    return 0


def regla_fichas(total):
    """Puntos mínimos por ficha para una zona de `total` ítems, listos para mostrar."""
    import math
    return [{"min": math.ceil(fr * total - 1e-9), "fichas": n} for fr, n in sorted(UMBRALES, key=lambda x: x[1])]


def extras_ok(g, tema):
    t = next(x for x in TEMAS if x["id"] == tema)
    return sum(1 for q in t.get("extras", []) if g["resp"].get(q["id"], {}).get("ok"))


def tema_cerrado(g, tema):
    t = next(x for x in TEMAS if x["id"] == tema)
    return respondidas_tema(g, tema) >= len(t["preguntas"])


def fichas_tema(g, tema):
    if not tema_cerrado(g, tema):
        return 0
    t = next(x for x in TEMAS if x["id"] == tema)
    return min(PIEZAS_POR_TEMA, fichas_base(aciertos_tema(g, tema), len(t["preguntas"])) + extras_ok(g, tema) + g["manual"].get(str(tema), 0))


def principal_cerrado(g):
    """Las 4 zonas están respondidas."""
    return all(tema_cerrado(g, t["id"]) for t in TEMAS)


def reto_entregado(g):
    return bool(g.get("reto") and g["reto"].get("entregado_en"))


def todo_calificado(g):
    """4 zonas + reto final entregados: se cierra la nota y se habilitan los retos extra."""
    return principal_cerrado(g) and reto_entregado(g)


def reto_frac(g):
    """Fracción del reto final (crucigrama y sopa pesan igual)."""
    r = g.get("reto")
    if not r or not r.get("entregado_en"):
        return 0.0
    return 0.5 * r["cw_ok"] / max(1, r["cw_total"]) + 0.5 * r["sopa_ok"] / max(1, r["sopa_total"])


def _pal(s):
    return "".join(c for c in _sin_tildes(s).upper() if c.isalpha())


def _linea(grid, r1, c1, r2, c2):
    dr, dc = r2 - r1, c2 - c1
    n_ = len(grid)
    if not all(isinstance(x, int) and 0 <= x < n_ for x in (r1, c1, r2, c2)):
        return None
    if not (dr == 0 or dc == 0 or abs(dr) == abs(dc)):
        return None
    n = max(abs(dr), abs(dc))
    sr, sc = (dr > 0) - (dr < 0), (dc > 0) - (dc < 0)
    return "".join(grid[r1 + sr * i][c1 + sc * i] for i in range(n + 1))


def responsable(g, i):
    m = integrantes_lista(g)
    return m[i % len(m)] if m else ""


def vista_reto(g):
    """Crucigrama y sopa SIN respuestas. Cada pista se asigna a un integrante (trabajo en equipo)."""
    cw = RETO["crucigrama"]
    sp = RETO["sopa"]
    return {
        "peso": PESO_RETO,
        "crucigrama": {"filas": cw["filas"], "cols": cw["cols"], "entradas": [
            {"clave": f"{e['n']}{e['dir']}", "n": e["n"], "dir": e["dir"], "r": e["r"], "c": e["c"],
             "largo": len(e["respuesta"]), "pista": e["pista"], "resp": responsable(g, i)}
            for i, e in enumerate(cw["entradas"])]},
        "sopa": {"n": sp["n"], "grid": sp["grid"], "palabras": [
            {"i": i, "largo": len(p["palabra"]), "pista": p["pista"], "resp": responsable(g, i + 1)}
            for i, p in enumerate(sp["palabras"])]},
    }


def calificar_reto(g, b):
    """Califica el reto final. Se entrega una sola vez."""
    cw = RETO["crucigrama"]
    sp = RETO["sopa"]
    dic = b.get("cw") if isinstance(b.get("cw"), dict) else {}
    cw_ok_claves = []
    for e in cw["entradas"]:
        k = f"{e['n']}{e['dir']}"
        if _pal(dic.get(k, "")) == e["respuesta"]:
            cw_ok_claves.append(k)
    objetivo = {p["palabra"] for p in sp["palabras"]}
    halladas = set()
    sels = b.get("sopa") if isinstance(b.get("sopa"), list) else []
    for s in sels[:300]:
        try:
            r1, c1, r2, c2 = s
            txt = _linea(sp["grid"], r1, c1, r2, c2)
        except Exception:
            continue
        if txt and txt in objetivo:
            halladas.add(txt)
        elif txt and txt[::-1] in objetivo:
            halladas.add(txt[::-1])
    g["reto"] = {"entregado_en": time.time(), "cw_ok": len(cw_ok_claves), "cw_total": len(cw["entradas"]),
                 "cw_claves_ok": cw_ok_claves, "sopa_ok": len(halladas), "sopa_total": len(objetivo),
                 "sopa_halladas": sorted(halladas)}
    return g["reto"]


def total_fichas(g):
    return sum(fichas_tema(g, t["id"]) for t in TEMAS)


def aciertos_principal(g):
    return sum(aciertos_tema(g, t["id"]) for t in TEMAS)


def n_salidas(g):
    return len(g["salidas"])


def penalizacion(n):
    return max(0, n - SALIDAS_GRATIS) * DESCUENTO_SALIDA


def nota_bruta(g):
    """85 % las 4 zonas + 15 % el reto final (crucigrama y sopa), sobre 10."""
    return NOTA_MAX * ((1 - PESO_RETO) * aciertos_principal(g) / TOTAL_PRINCIPAL + PESO_RETO * reto_frac(g))


def nota_vista(g):
    n = g["salidas_cierre"] if g["salidas_cierre"] is not None else n_salidas(g)
    return round(max(0.0, nota_bruta(g) - penalizacion(n)), 2)



def revisar_cierre_y_ganador(g):
    ahora = time.time()
    if g["cierre_principal"] is None and todo_calificado(g):
        g["cierre_principal"] = ahora
        g["salidas_cierre"] = n_salidas(g)
        g["nota"] = nota_vista(g)
    if todo_calificado(g) and total_fichas(g) >= TOTAL_PIEZAS and reto_frac(g) >= MIN_RETO_GANAR and g["completado_en"] is None:
        g["completado_en"] = ahora
        if ESTADO.get("ganador") is None:
            if get_db().claim_ganador(g["id"]):
                ESTADO["ganador"] = g["id"]
            else:
                ESTADO["ganador"] = get_db().config().get("ganador")


def vista_pregunta(g, q):
    """Pregunta sin clave, con las opciones mezcladas de forma distinta por grupo."""
    base = {"id": q["id"], "tipo": q["tipo"], "enunciado": q["enunciado"], "nivel": q.get("nivel", "")}
    if q["tipo"] == "match":
        idx = list(range(len(q["derecha"])))
        random.Random(f"{g['id']}:{q['id']}").shuffle(idx)
        base["izquierda"] = list(q["izquierda"])
        base["derecha"] = [{"k": i, "texto": q["derecha"][i]} for i in idx]
        return base
    if q["tipo"] == "fill":
        idx = list(range(len(q["banco"])))
        random.Random(f"{g['id']}:{q['id']}").shuffle(idx)
        base["texto"] = q["texto"]
        base["huecos"] = len(q["correcta"])
        base["banco"] = [{"k": i, "texto": q["banco"][i]} for i in idx]
        return base
    idx = list(range(len(q["opciones"])))
    random.Random(f"{g['id']}:{q['id']}").shuffle(idx)
    base["opciones"] = [{"k": i, "texto": q["opciones"][i]} for i in idx]
    return base


def siguiente_principal(g):
    for t in TEMAS:
        for qid in preguntas_principales(g, t["id"]):
            if qid not in g["resp"]:
                return t["id"], qid
    return None, None


def siguiente_extra(g, tema):
    t = next(x for x in TEMAS if x["id"] == tema)
    for q in t.get("extras", []):
        if q["id"] not in g["resp"]:
            return q["id"]
    return None


def corregir(q, sel):
    """Devuelve los puntos de la respuesta: 0 a 1. Relacionar y completar dan crédito parcial."""
    if not isinstance(sel, list):
        return 0.0
    if q["tipo"] == "single":
        return 1.0 if len(sel) == 1 and sel[0] in q["correcta"] else 0.0
    if q["tipo"] == "multi":
        return 1.0 if sorted(set(sel)) == sorted(q["correcta"]) else 0.0
    if q["tipo"] == "order":
        return 1.0 if sel == list(range(len(q["opciones"]))) else 0.0
    if q["tipo"] in ("match", "fill"):
        n = len(q["correcta"])
        if len(sel) != n:
            return 0.0
        return sum(1 for a, b in zip(sel, q["correcta"]) if a == b) / n
    return 0.0


def texto_correcto(q):
    if q["tipo"] == "order":
        return [q["opciones"][i] for i in range(len(q["opciones"]))]
    if q["tipo"] == "match":
        return [f"{a}  →  {q['derecha'][c]}" for a, c in zip(q["izquierda"], q["correcta"])]
    if q["tipo"] == "fill":
        return [f"({i + 1}) {q['banco'][c]}" for i, c in enumerate(q["correcta"])]
    return [q["opciones"][i] for i in q["correcta"]]


def resumen_temas(g):
    out = []
    for t in TEMAS:
        cerrado = tema_cerrado(g, t["id"])
        faltan = PIEZAS_POR_TEMA - fichas_tema(g, t["id"]) if cerrado else PIEZAS_POR_TEMA
        quedan_extras = len([q for q in t.get("extras", []) if q["id"] not in g["resp"]])
        out.append({
            "id": t["id"], "nombre": t["nombre"], "zona": t["zona"], "intro": t["intro"],
            "total": len(t["preguntas"]), "respondidas": respondidas_tema(g, t["id"]),
            "aciertos": round(aciertos_tema(g, t["id"]), 2), "cerrado": cerrado,
            "regla": regla_fichas(len(t["preguntas"])),
            "fichas": fichas_tema(g, t["id"]), "faltan": faltan if cerrado else None,
            "extras_quedan": quedan_extras,
            "extras_total": len(t.get("extras", [])),
        })
    return out



def tablero(actual=None):
    filas = []
    for r in get_db().resumen():
        if actual and r["id"] == actual["id"]:
            continue
        filas.append({"id": r["id"], "nombre": r["nombre"], "fichas": r["fichas"] or 0, "completado_en": r["completado_en"]})
    if actual:
        filas.append({"id": actual["id"], "nombre": actual["nombre"], "fichas": total_fichas(actual), "completado_en": actual["completado_en"]})
    filas.sort(key=lambda r: (-r["fichas"], r["completado_en"] or 9e18, r["nombre"].lower()))
    return filas


def estado_grupo(g):
    revisar_cierre_y_ganador(g)
    tema, qid = siguiente_principal(g)
    if qid:
        fase = "principal"
    elif not reto_entregado(g):
        fase = "reto_final"
    else:
        fase = "completo" if total_fichas(g) >= TOTAL_PIEZAS else "extras"
    rr = g.get("reto") or {}
    pregunta = vista_pregunta(g, PREG[qid][0]) if qid else None
    n = n_salidas(g)
    tab = tablero(g)
    gid = ESTADO.get("ganador")
    nombre_gan = next((r["nombre"] for r in tab if r["id"] == gid), None) if gid else None
    return {
        "grupo": {"id": g["id"], "nombre": g["nombre"], "integrantes": g["integrantes"]},
        "miembros": integrantes_lista(g), "turno": responsable(g, len(g["resp"])),
        "abierto": ESTADO["abierto"], "fase": fase, "tema_actual": tema,
        "pregunta": pregunta,
        "reto": {"peso": PESO_RETO, "entregado": reto_entregado(g), "cw_ok": rr.get("cw_ok", 0), "cw_total": len(RETO["crucigrama"]["entradas"]),
                 "sopa_ok": rr.get("sopa_ok", 0), "sopa_total": len(RETO["sopa"]["palabras"]),
                 "cw_claves_ok": rr.get("cw_claves_ok", []), "sopa_halladas": rr.get("sopa_halladas", [])},
        "vista_reto": vista_reto(g) if fase == "reto_final" else None,
        "peso_reto": PESO_RETO, "reto_ok_ganar": reto_frac(g) >= MIN_RETO_GANAR, "min_reto_ganar": MIN_RETO_GANAR,
        "total_principal": TOTAL_PRINCIPAL, "respondidas_principal": sum(respondidas_tema(g, t["id"]) for t in TEMAS),
        "temas": resumen_temas(g),
        "piezas": [[i < fichas_tema(g, t["id"]) for i in range(PIEZAS_POR_TEMA)] for t in TEMAS],
        "total_fichas": total_fichas(g), "total_piezas": TOTAL_PIEZAS,
        "salidas": n, "salidas_gratis": SALIDAS_GRATIS, "descuento": DESCUENTO_SALIDA,
        "penalizacion_actual": penalizacion(g["salidas_cierre"] if g["salidas_cierre"] is not None else n),
        "nota": nota_vista(g), "nota_final": g["cierre_principal"] is not None,
        "aciertos": round(aciertos_principal(g), 2),
        "ganador": nombre_gan, "yo_gano": gid == g["id"],
        "tablero": tab,
    }


def panel():
    filas = []
    ahora = time.time()
    for g in ESTADO["grupos"].values():
        revisar_cierre_y_ganador(g)
        n = n_salidas(g)
        fuera = bool(g["salidas"]) and g["salidas"][-1].get("fin") is None
        filas.append({
            "id": g["id"], "nombre": g["nombre"], "pin": g["pin"], "integrantes": g["integrantes"],
            "en_linea": ahora - g["ultimo_latido"] < 20, "fuera_ahora": fuera and ahora - g["ultimo_latido"] < 30,
            "salidas": n, "penalizacion": penalizacion(g["salidas_cierre"] if g["salidas_cierre"] is not None else n),
            "respondidas": sum(respondidas_tema(g, t["id"]) for t in TEMAS), "total": TOTAL_PRINCIPAL,
            "aciertos": round(aciertos_principal(g), 2), "nota": nota_vista(g), "nota_final": g["cierre_principal"] is not None,
            "reto": {"entregado": reto_entregado(g), "cw_ok": (g.get("reto") or {}).get("cw_ok", 0), "cw_total": len(RETO["crucigrama"]["entradas"]),
                     "sopa_ok": (g.get("reto") or {}).get("sopa_ok", 0), "sopa_total": len(RETO["sopa"]["palabras"])},
            "fichas": total_fichas(g), "temas": resumen_temas(g),
            "extras_resp": sum(1 for q, (_, _, ex) in PREG.items() if ex and q in g["resp"]),
            "completado_en": g["completado_en"],
            "salidas_detalle": [{"ini": s["ini"], "fin": s["fin"]} for s in g["salidas"]],
        })
    filas.sort(key=lambda r: (-r["fichas"], r["completado_en"] or 9e18, r["nombre"].lower()))
    gan = ESTADO["grupos"].get(ESTADO.get("ganador"))
    return {"abierto": ESTADO["abierto"], "iniciado_en": ESTADO["iniciado_en"], "total_piezas": TOTAL_PIEZAS,
            "ganador": gan["nombre"] if gan else None, "grupos": filas, "ahora": ahora,
            "preguntas": dificiles(ESTADO["grupos"].values()),
            "reglas": {"gratis": SALIDAS_GRATIS, "descuento": DESCUENTO_SALIDA}}


# ---------- informes PDF (generador mínimo, sin dependencias) ----------
import textwrap


def _t(s):
    s = str(s)
    for a, b in (("→", "->"), ("—", "-"), ("–", "-"), ("−", "-"), ("“", '"'), ("”", '"'), ("’", "'"), ("✓", "OK"), ("✗", "X"), ("•", "-")):
        s = s.replace(a, b)
    return s.encode("cp1252", "replace")


def _esc(b):
    return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")


def pdf_bytes(lineas, pie):
    """lineas: lista de (texto, estilo) con estilo 'n' normal, 'b' negrita, 'h' título. Fuente Courier."""
    paginas, y = [[]], 800
    for texto, est in lineas:
        size = 13 if est == "h" else 9
        lh = size * 1.4
        if y - lh < 55:
            paginas.append([]); y = 800
        y -= lh
        paginas[-1].append((y, texto, est, size))
    objs = {1: b"<< /Type /Catalog /Pages 2 0 R >>",
            3: b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>",
            4: b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>"}
    kids = []
    for i, pg in enumerate(paginas):
        po, co = 5 + 2 * i, 6 + 2 * i
        kids.append(f"{po} 0 R")
        partes = []
        for yy, texto, est, size in pg:
            fuente = "F2" if est in ("b", "h") else "F1"
            partes.append(b"BT /" + fuente.encode() + f" {size} Tf 40 {yy:.1f} Td (".encode() + _esc(_t(texto)) + b") Tj ET")
        partes.append(b"BT /F1 8 Tf 40 30 Td (" + _esc(_t(f"{pie}  -  pagina {i + 1} de {len(paginas)}")) + b") Tj ET")
        stream = b"\n".join(partes)
        objs[co] = b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream"
        objs[po] = (f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents {co} 0 R "
                    f"/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>").encode()
    objs[2] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>".encode()
    out, offs = bytearray(b"%PDF-1.4\n"), {}
    for n in sorted(objs):
        offs[n] = len(out)
        out += f"{n} 0 obj\n".encode() + objs[n] + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    for n in sorted(objs):
        out += f"{offs[n]:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)


def _envolver(texto, ancho=92, sangria=""):
    return [sangria + l for l in textwrap.wrap(str(texto), ancho - len(sangria))] or [sangria]


def _hora(t):
    return time.strftime("%H:%M:%S", time.localtime(t)) if t else "-"


def _resp_texto(q, sel):
    if sel is None:
        return "(sin respuesta)"
    try:
        if q["tipo"] == "order":
            return " > ".join(q["opciones"][i] for i in sel)
        if q["tipo"] == "match":
            return "; ".join(f"{a} -> {q['derecha'][s] if isinstance(s, int) and 0 <= s < len(q['derecha']) else '(vacio)'}" for a, s in zip(q["izquierda"], sel))
        if q["tipo"] == "fill":
            return "; ".join(f"({i + 1}) {q['banco'][s] if isinstance(s, int) and 0 <= s < len(q['banco']) else '(vacio)'}" for i, s in enumerate(sel))
        return "; ".join(q["opciones"][i] for i in sel)
    except Exception:
        return "(sin respuesta)"


def _f1(x):
    return f"{x:.1f}".replace(".", ",")


def informe_estudiante(g):
    L = [("INFORME DEL GRUPO - OBRA MALDITA", "h"), (BANCO["asignatura"], "b"), ("", "n")]
    L += [(f"Grupo: {g['nombre']}", "b")] + [(l, "n") for l in _envolver("Integrantes: " + (g["integrantes"] or "-"))]
    L += [(f"Fecha: {time.strftime('%d/%m/%Y %H:%M')}", "n"), ("", "n")]
    n = g["salidas_cierre"] if g["salidas_cierre"] is not None else n_salidas(g)
    L += [("RESULTADO", "b"),
          (f"Puntos en las 4 zonas ({round((1 - PESO_RETO) * 100)} % de la nota): {_f1(aciertos_principal(g))} de {TOTAL_PRINCIPAL}", "n"),
          ((f"Reto final ({round(PESO_RETO * 100)} % de la nota): crucigrama {g['reto']['cw_ok']}/{g['reto']['cw_total']} palabras, sopa de letras {g['reto']['sopa_ok']}/{g['reto']['sopa_total']} palabras" if reto_entregado(g) else "Reto final: sin entregar"), "n"),
          (f"Salidas de pantalla: {n} (gratis: {SALIDAS_GRATIS}; descuento: -{str(penalizacion(n)).replace('.', ',')} )", "n"),
          (f"Nota del grupo: {str(nota_vista(g)).replace('.', ',')} / 10", "b"),
          (f"Fichas del rompecabezas: {total_fichas(g)} de {TOTAL_PIEZAS}", "n"),
          (("Completaron el rompecabezas a las " + _hora(g["completado_en"])) if g["completado_en"] else "Rompecabezas: incompleto", "n"),
          (("GANADOR DEL RETO: +1 punto directo en la evaluacion de corte") if ESTADO["ganador"] == g["id"] else "", "b"),
          ("", "n"), ("FICHAS POR ZONA", "b")]
    for t in TEMAS:
        L.append((f"Zona {t['id']} - {t['zona']}: {_f1(aciertos_tema(g, t['id']))}/{len(t['preguntas'])} puntos, {fichas_tema(g, t['id'])}/{PIEZAS_POR_TEMA} fichas", "n"))
    L += [("", "n"), ("DETALLE DE PREGUNTAS", "b"), ("(OK = correcta, PARCIAL = algunas partes bien, X = incorrecta)", "n"), ("", "n")]
    for t in TEMAS:
        L += [(f"Zona {t['id']}: {t['nombre']}", "b")]
        for i, q in enumerate(t["preguntas"], 1):
            r = g["resp"].get(q["id"])
            p = puntos(r) if r else 0.0
            marca = "OK" if p >= 0.999 else ("PARCIAL " + _f1(p) + "/1" if p > 0 else "X")
            L += [(l, "n") for l in _envolver(f"{i}. [{marca}] ({q['tipo']}) {q['enunciado']}")]
            if r and p < 0.999:
                L += [(l, "n") for l in _envolver("Su grupo respondio: " + _resp_texto(q, r["sel"]), sangria="     ")]
                L += [(l, "b") for l in _envolver("Correcta: " + ("; ".join(texto_correcto(q)) if q["tipo"] != "order" else " > ".join(q["opciones"])), sangria="     ")]
            L += [(l, "n") for l in _envolver("Por que: " + q["explicacion"], sangria="     ")]
            L.append(("", "n"))
    if reto_entregado(g):
        L += [("RETO FINAL", "b"),
              (f"Crucigrama: {g['reto']['cw_ok']} de {g['reto']['cw_total']} palabras correctas.", "n"),
              (f"Sopa de letras: {g['reto']['sopa_ok']} de {g['reto']['sopa_total']} palabras halladas ({', '.join(g['reto']['sopa_halladas']) or 'ninguna'}).", "n"), ("", "n")]
    ex = [(q, g["resp"][q["id"]]) for t in TEMAS for q in t.get("extras", []) if q["id"] in g["resp"]]
    if ex:
        L += [("RETOS EXTRA", "b")]
        for q, r in ex:
            L += [(l, "n") for l in _envolver(f"[{'OK' if puntos(r) >= 0.999 else 'X '}] Zona {PREG[q['id']][1]}: {q['enunciado']}")]
        L.append(("", "n"))
    L += [("Documento generado automaticamente por el sistema Obra Maldita.", "n")]
    return pdf_bytes(L, f"Informe del grupo {g['nombre']}")


def informe_docente():
    p = panel()
    L = [("INFORME DEL DOCENTE - OBRA MALDITA", "h"), (BANCO["asignatura"], "b"),
         (f"Generado: {time.strftime('%d/%m/%Y %H:%M')}", "n"),
         (f"Reto: {'abierto' if p['abierto'] else 'cerrado'}   Grupos: {len(p['grupos'])}", "n"),
         ((f"GANADOR: {p['ganador']} (+1 punto directo en la evaluacion de corte)" if p["ganador"] else "Ganador: aun no hay"), "b"),
         (f"Nota = {round((1 - PESO_RETO) * 100)} % zonas ({TOTAL_PRINCIPAL} puntos) + {round(PESO_RETO * 100)} % reto final (crucigrama y sopa), sobre 10, menos el descuento por salidas ({SALIDAS_GRATIS} gratis, luego -{str(DESCUENTO_SALIDA).replace('.', ',')} c/u).", "n"),
         ("", "n"), ("RESUMEN", "b"),
         ("Grupo               Puntos   Cruci. Sopa Salid. Desc.  Nota  Fichas Completo", "b")]
    for r in p["grupos"]:
        rt = r["reto"]
        cw = f"{rt['cw_ok']}/{rt['cw_total']}" if rt["entregado"] else "-"
        sp = f"{rt['sopa_ok']}/{rt['sopa_total']}" if rt["entregado"] else "-"
        L.append((f"{r['nombre'][:19]:<19} {_f1(r['aciertos']):>5}/{r['total']:<3} {cw:>6} {sp:>5} {r['salidas']:>5} {str(r['penalizacion']).replace('.', ','):>5} {str(r['nota']).replace('.', ','):>6} {r['fichas']:>2}/{TOTAL_PIEZAS:<3} {_hora(r['completado_en'])}", "n"))
    if p.get("preguntas"):
        L += [("", "n"), ("PREGUNTAS CON MAS FALLOS (para repasar en clase)", "b")]
        for r in p["preguntas"]:
            L += [(l, "n") for l in _envolver(f"{r['id']} - {r['aciertos']}/{r['n']} grupos acertaron ({r['pct']}%): {r['texto']}", sangria="  ")]
    L += [("", "n"), ("DETALLE POR GRUPO", "b"), ("", "n")]
    for r in p["grupos"]:
        L += [(f"{r['nombre']}" + ("   [GANADOR]" if p["ganador"] == r["nombre"] else ""), "b")]
        L += [(l, "n") for l in _envolver("Integrantes: " + (r["integrantes"] or "-"), sangria="  ")]
        L += [(f"  Nota: {str(r['nota']).replace('.', ',')}/10 ({'final' if r['nota_final'] else 'provisional'}) - Puntos {_f1(r['aciertos'])}/{r['total']} - Retos extra respondidos: {r['extras_resp']}", "n")]
        L += [(f"  Zona {t['id']}: {_f1(t['aciertos'])}/{t['total']} puntos, {t['fichas']} fichas" + ("" if t["cerrado"] else " (sin terminar)"), "n") for t in r["temas"]]
        L.append(("  Reto final: " + (f"crucigrama {r['reto']['cw_ok']}/{r['reto']['cw_total']}, sopa {r['reto']['sopa_ok']}/{r['reto']['sopa_total']}" if r["reto"]["entregado"] else "sin entregar"), "n"))
        if r["salidas_detalle"]:
            for k, s in enumerate(r["salidas_detalle"], 1):
                dur = f"{int(round((s['fin'] or p['ahora']) - s['ini']))} s" + ("" if s["fin"] else " (sigue fuera)")
                L.append((f"  Salida {k}: {_hora(s['ini'])} - duracion {dur}", "n"))
        else:
            L.append(("  Sin salidas registradas.", "n"))
        L.append(("", "n"))
    return pdf_bytes(L, "Informe del docente - Obra Maldita")



# ---------- HTTP ----------
class handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 200_000:
            return {}
        try:
            return json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return {}

    def _cargar(self, todos=False):
        cfg = get_db().config()
        ESTADO.clear()
        ESTADO.update({"abierto": bool(cfg.get("abierto")), "iniciado_en": cfg.get("iniciado_en"),
                       "ganador": cfg.get("ganador"), "grupos": get_db().grupos() if todos else {}})

    def _grupo(self):
        auth = self.headers.get("Authorization", "")
        gid = verificar(auth[7:]) if auth.startswith("Bearer ") else None
        if not gid:
            return None
        g = get_db().grupo(gid)
        if g:
            ESTADO["grupos"][gid] = g
        return g

    def _docente(self):
        c = env("DOCENTE_CLAVE")
        return bool(c) and secrets.compare_digest(self.headers.get("X-Docente-Clave", ""), c)

    def _ruta(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if "ruta" in q:
            return "/api/" + q["ruta"][0].strip("/"), q
        return u.path, q

    def do_GET(self):
        self._despachar("GET")

    def do_POST(self):
        self._despachar("POST")

    def _despachar(self, metodo):
        try:
            ruta, q = self._ruta()
            if not env("SUPABASE_URL") or not env("SUPABASE_SERVICE_KEY") or not env("SESSION_SECRET"):
                return self._json({"error": "Servidor sin configurar (faltan variables de entorno)"}, 503)
            body = self._body() if metodo == "POST" else None
            with LOCK:  # ESTADO es global por proceso: una petición a la vez
                self._cargar()
                if metodo == "GET":
                    return self._get(ruta, q)
                return self._post(ruta, body)
        except ErrorBD:
            return self._json({"error": "Error temporal de base de datos. Intenta de nuevo."}, 503)
        except Exception as e:
            traceback.print_exc(file=sys.stderr)
            return self._json({"error": "Error interno"}, 500)

    def _pdf(self, data, nombre):
        self.send_response(200)
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Disposition", f'attachment; filename="{nombre}"')
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _get(self, ruta, q):
        if ruta == "/api/grupos-publicos":
            return self._json([{"id": r["id"], "nombre": r["nombre"]} for r in get_db().resumen()])
        if ruta == "/api/acertijo":
            g = get_db().grupo(q.get("id", [""])[0])
            if not g:
                return self._json({"error": "grupo"}, 404)
            return self._json({"nombre": g["nombre"], "letras": acertijo_grupo(g)})
        if ruta == "/api/estado":
            g = self._grupo()
            if not g:
                return self._json({"error": "sesion"}, 401)
            ahora = time.time()
            cambio = ahora - g["ultimo_latido"] > 8
            if cambio:
                g["ultimo_latido"] = ahora
            antes = json.dumps(g, sort_keys=True)
            r = estado_grupo(g)
            if cambio or json.dumps(g, sort_keys=True) != antes:
                get_db().guardar_grupo(g)
            return self._json(r)
        if ruta == "/api/pregunta-extra":
            g = self._grupo()
            if not g:
                return self._json({"error": "sesion"}, 401)
            try:
                tema = int(q.get("tema", ["0"])[0])
            except ValueError:
                tema = 0
            if not ESTADO["abierto"] or not todo_calificado(g) or total_fichas(g) >= TOTAL_PIEZAS:
                return self._json({"error": "no_disponible"}, 403)
            if not (1 <= tema <= NUM_TEMAS) or not tema_cerrado(g, tema) or fichas_tema(g, tema) >= PIEZAS_POR_TEMA:
                return self._json({"pregunta": None})
            qid = siguiente_extra(g, tema)
            return self._json({"pregunta": vista_pregunta(g, PREG[qid][0]) if qid else None})
        if ruta == "/api/informe-pdf":
            g = self._grupo()
            if not g:
                return self._json({"error": "sesion"}, 401)
            revisar_cierre_y_ganador(g)
            if g["cierre_principal"] is None:
                return self._json({"error": "El informe se habilita al terminar las 4 zonas"}, 403)
            nombre = "informe_" + "".join(c if c.isalnum() else "_" for c in g["nombre"]) + ".pdf"
            return self._pdf(informe_estudiante(g), nombre)
        if ruta == "/api/docente/panel":
            if not self._docente():
                return self._json({"error": "clave"}, 401)
            self._cargar(todos=True)
            return self._json(panel())
        if ruta == "/api/docente/informe-pdf":
            if not self._docente():
                return self._json({"error": "clave"}, 401)
            self._cargar(todos=True)
            return self._pdf(informe_docente(), "informe_docente_obra_maldita.pdf")
        return self._json({"error": "ruta"}, 404)

    def _post(self, ruta, b):
        if ruta == "/api/login":
            g = get_db().grupo(str(b.get("id", "")))
            if not g:
                return self._json({"error": "Grupo no encontrado"}, 401)
            fallos_antes = g.get("fallos", 0)
            codigo = intentar_ingreso(g, b)
            if codigo != "bloqueado" and (codigo == "mal" or fallos_antes):
                get_db().guardar_grupo(g)
            if codigo == "bloqueado":
                return self._json({"error": "Demasiados intentos. Esperen un minuto e inténtenlo de nuevo."}, 429)
            if codigo != "ok":
                return self._json({"error": "Esos nombres no abren la puerta. Descifren mejor las letras."}, 401)
            return self._json({"token": firmar(g["id"])})
        if ruta.startswith("/api/docente/"):
            if not self._docente():
                return self._json({"error": "clave"}, 401)
            return self._docente_post(ruta, b)
        g = self._grupo()
        if not g:
            return self._json({"error": "sesion"}, 401)
        if ruta == "/api/responder":
            return self._responder(g, b)
        if ruta == "/api/salida":
            return self._salida(g, b)
        if ruta == "/api/reto":
            return self._reto(g, b)
        return self._json({"error": "ruta"}, 404)

    def _responder(self, g, b):
        if not ESTADO["abierto"]:
            return self._json({"error": "El reto aún no está abierto"}, 403)
        qid = b.get("qid")
        if qid not in PREG:
            return self._json({"error": "pregunta"}, 400)
        q, tema, es_extra = PREG[qid]
        if qid in g["resp"]:
            r = g["resp"][qid]
        else:
            if es_extra:
                if not todo_calificado(g) or fichas_tema(g, tema) >= PIEZAS_POR_TEMA:
                    return self._json({"error": "no_disponible"}, 403)
            else:
                _, esperada = siguiente_principal(g)
                if qid != esperada:
                    return self._json({"error": "fuera_de_orden"}, 409)
            sel = b.get("sel")
            p = corregir(q, sel)
            g["resp"][qid] = {"sel": sel, "ok": p >= 0.999, "p": round(p, 4), "t": time.time()}
            r = g["resp"][qid]
            revisar_cierre_y_ganador(g)
            get_db().guardar_grupo(g)
        p = puntos(r)
        return self._json({"ok": p >= 0.999, "puntos": p, "parcial": 0 < p < 0.999, "correcta": texto_correcto(q),
                           "explicacion": q["explicacion"], "tipo": q["tipo"], "estado": estado_grupo(g)})

    def _reto(self, g, b):
        if not ESTADO["abierto"]:
            return self._json({"error": "El reto aún no está abierto"}, 403)
        if not principal_cerrado(g):
            return self._json({"error": "Primero terminen las 4 zonas"}, 403)
        if not reto_entregado(g):
            calificar_reto(g, b)
            revisar_cierre_y_ganador(g)
            get_db().guardar_grupo(g)
        return self._json({"estado": estado_grupo(g)})

    def _salida(self, g, b):
        ahora = time.time()
        if b.get("tipo") == "salida":
            if not g["salidas"] or g["salidas"][-1].get("fin") is not None:
                g["salidas"].append({"ini": ahora, "fin": None})
        elif b.get("tipo") == "regreso":
            if g["salidas"] and g["salidas"][-1].get("fin") is None:
                g["salidas"][-1]["fin"] = ahora
        g["ultimo_latido"] = ahora
        get_db().guardar_grupo(g)
        n = n_salidas(g)
        return self._json({"salidas": n, "penalizacion": penalizacion(n)})

    def _docente_post(self, ruta, b):
        db = get_db()
        if ruta == "/api/docente/abrir":
            abierto = bool(b.get("abierto"))
            campos = {"abierto": abierto}
            if abierto and not ESTADO["iniciado_en"]:
                campos["iniciado_en"] = time.time()
            db.set_config(campos)
        elif ruta == "/api/docente/grupo":
            nombre = (b.get("nombre") or "").strip()
            if not nombre:
                return self._json({"error": "Falta el nombre"}, 400)
            pin = str(b.get("pin") or "").strip() or "".join(secrets.choice("0123456789") for _ in range(4))
            db.guardar_grupo(nuevo_grupo(nombre, pin, b.get("integrantes") or "")[1])
        elif ruta == "/api/docente/grupos-lote":
            for linea in (b.get("texto") or "").splitlines():
                partes = [p.strip() for p in linea.split(";")]
                if not partes or not partes[0]:
                    continue
                pin = partes[1] if len(partes) > 1 and partes[1] else "".join(secrets.choice("0123456789") for _ in range(4))
                db.guardar_grupo(nuevo_grupo(partes[0], pin, partes[2] if len(partes) > 2 else "")[1])
        elif ruta == "/api/docente/ficha":
            g = db.grupo(str(b.get("gid", "")))
            tema = str(b.get("tema"))
            if g and tema.isdigit() and 1 <= int(tema) <= NUM_TEMAS and tema_cerrado(g, int(tema)):
                if fichas_tema(g, int(tema)) < PIEZAS_POR_TEMA:
                    ESTADO["grupos"][g["id"]] = g
                    g["manual"][tema] = g["manual"].get(tema, 0) + 1
                    revisar_cierre_y_ganador(g)
                    db.guardar_grupo(g)
        elif ruta == "/api/docente/reiniciar":
            g = db.grupo(str(b.get("gid", "")))
            if g:
                nuevo = nuevo_grupo(g["nombre"], g["pin"], g["integrantes"])[1]
                nuevo["id"] = g["id"]
                db.guardar_grupo(nuevo)
                if ESTADO.get("ganador") == g["id"]:
                    db.set_config({"ganador": None})
        elif ruta == "/api/docente/eliminar":
            gid = str(b.get("gid", ""))
            db.eliminar(gid)
            if ESTADO.get("ganador") == gid:
                db.set_config({"ganador": None})
        elif ruta == "/api/docente/reiniciar-todo":
            if b.get("confirmar") == "BORRAR":
                db.borrar_todo()
        else:
            return self._json({"error": "ruta"}, 404)
        self._cargar(todos=True)
        return self._json(panel())
